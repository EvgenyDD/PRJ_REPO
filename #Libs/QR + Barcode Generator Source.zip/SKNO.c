/* Includes ------------------------------------------------------------------*/
#include "SKNO.h"
#include "debug.h"
#include "macros.h"


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
#define SKNOSetTimeout(ms) SKNOTimeout = 2*(ms);


/* Global variables ----------------------------------------------------------*/
uint16_t SKNOTimeout;


/* Private variables ---------------------------------------------------------*/
static uint8_t SKNOTxBuf[150];
static uint8_t SKNORxBuf[150];
static uint8_t phase = 0;

static uint16_t SKNORxCnt = 0;
static uint16_t SKNODataSize;
static uint16_t _status;

SKNOStatusTypeDef SKNOStatus;
uint16_t SKNOStatusNum;

FPRegistrationDataType FPData;


/* Extern variables ----------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*******************************************************************************
* Function Name  : SKNOInit
* Description    : Initialize SKNO module
*******************************************************************************/
void SKNOInit()
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);

	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	USART_InitTypeDef USART_InitStructure;
	USART_InitStructure.USART_BaudRate = 9600;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART2, &USART_InitStructure);

	//USART RX
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 4;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
	NVIC_EnableIRQ(USART2_IRQn);

	USART_Cmd(USART2, ENABLE);

	ClearBuffer(SKNORxBuf, 20, 0);
}


/*******************************************************************************
* Function Name  : USART2_IRQHandler
*******************************************************************************/
void USART2_IRQHandler()
{
	// Check if the USART2 receive interrupt flag was set
	if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)
	{
		USART_ClearITPendingBit(USART2, USART_IT_RXNE);
		uint8_t t = USART2->DR;

		SKNORxBuf[SKNORxCnt++] = t; //USART2->DR;

		if(SKNORxCnt > 1)
		{
			if(SKNORxBuf[SKNORxCnt - 2] == _SKNO_START)
			{
				switch(SKNORxBuf[SKNORxCnt - 1])
				{
				case _SKNO_STX: //packet start
					SKNORxCnt = 0;

					if(phase == SKNO_REQ_RECEIVING)
					{
						_status = SKNORxBuf[1] | (SKNORxBuf[0] << 8);
						phase = SKNO_REQ_RECEIVED | SKNO_PKT_RECEIVING;
						break;
					}

					phase = SKNO_PKT_RECEIVING;
					break;

				case _SKNO_ETX: //packet end
					if(phase == SKNO_PKT_RECEIVING)
					{
						SKNODataSize = SKNORxCnt - 2;
						phase = SKNO_PKT_RECEIVED;
					}
					else //phase == SKNO_REQ_RECEIVING
					{
						_status = SKNORxBuf[1] | (SKNORxBuf[0] << 8);
						phase = SKNO_REQ_RECEIVED;
					}
					SKNORxCnt = 0;
					break;

				case _SKNO_EOT: //error
					SKNORxCnt = 0;
					phase = SKNO_ERROR;
					break;

				case _SKNO_ACK:
					SKNORxCnt = 0;
					phase = SKNO_PKT_ACKED;
					break;

				case _SKNO_NACK:
					SKNORxCnt = 0;
					phase = SKNO_PKT_NACKED;
					break;

				case _SKNO_SOH: //start of status info
					SKNORxCnt = 0;
					phase = SKNO_REQ_RECEIVING;
					break;

				case _SKNO_DUMMY: //don't use byte-insertion
					SKNORxCnt--;
					return;
					break;
				}
			}
		}

		if(t == 0x17)
		{
			DebugSendChar('\n');
		}

		DebugSendChar('*');
		DebugSendNumWSpaceHex(t);

//		static uint8_t prevphase = 0;
//		if(prevphase != phase) //debug phase state
//		{
//			prevphase = phase;
//			DebugSendChar('-');
//			DebugSendNumWSpace(phase);
//		}


		if(SKNORxCnt % 40 == 0)
			DebugSendChar('\n');
	}
}


/*******************************************************************************
* Function Name  : _SKNOSendByte
* Description    : Send data byte to SKNO
*******************************************************************************/
static void _SKNOSendByte(uint8_t byte)
{
	while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
	USART_SendData(USART2, byte);
}


/*******************************************************************************
* Function Name  : _SKNOSendAck
* Description    : Send ACK to SKNO
*******************************************************************************/
static void _SKNOSendAck()
{
	_SKNOSendByte(_SKNO_START);
	_SKNOSendByte(_SKNO_ACK);
}


/*******************************************************************************
* Function Name  : _SKNOSendNack
* Description    : Send NACK to SKNO
*******************************************************************************/
static void _SKNOSendNack()
{
	_SKNOSendByte(_SKNO_START);
	_SKNOSendByte(_SKNO_NACK);
}


/*******************************************************************************
* Function Name  : CRC16_CCITT_CalcMass
* Description    : Calculate CRC16
*******************************************************************************/
uint16_t CRC16_CCITT_CalcMass(uint8_t *data, uint16_t size)
{
	uint8_t x;
	uint16_t crc = 0xFFFF;

	while(size--)
	{
		x = crc >> 8 ^ *data++;
		x ^= x >> 4;
		crc = (crc << 8) ^ ((uint16_t)(x << 12)) ^ ((uint16_t)(x << 5)) ^ ((uint16_t) x);
	}
	return crc;
}


/*******************************************************************************
* Function Name  : _SKNO_CRC16Compare
* Description    : Compare received data's CRC
*******************************************************************************/
static int8_t _SKNO_CRC16Compare(uint8_t *data, uint16_t length)
{
	uint16_t calc = CRC16_CCITT_CalcMass(data, length);
	//DebugSendNumWDesc("CRC calculated: ", calc);
	if(data[length] == ((calc >> 8) & 0xFF) && data[length + 1] == (calc & 0xFF))
		return STATUS_SUCCESSFULL;
	else
		return STATUS_ERROR;
}


/*******************************************************************************
* Function Name  : _MassInsert
* Description    : Insert number in the massive at specified position
*******************************************************************************/
static void _MassInsert(uint8_t *mass, uint16_t pos, uint16_t totalLen, uint16_t number)
{
	uint8_t temp = mass[pos], new;
	mass[pos] = number;

	for(uint16_t i = pos + 1; i < totalLen + 1; i++)
	{
		new = mass[i];
		mass[i] = temp;
		temp = new;
	}
}


/*******************************************************************************
* Function Name  : _SKNOInsert12
* Description    : Replace 0x17 -> 0x17 0x12 in TX mass
*******************************************************************************/
static uint16_t _SKNOInsert12(uint8_t *mass, uint8_t size)
{
	for(uint16_t i=0; i<size; i++)
	{
		if(mass[i] == 0x17)
		{
			_MassInsert(mass, i, size++, 0x12);
			DebugSendNumWDesc("Inserted in:", i);
		}
	}

	return size;
}


/*******************************************************************************
* Function Name  : _SKNOSendPacket
* Description    : Send data packet to SKNO
*******************************************************************************/
static void _SKNOSendPacket(uint8_t command, uint16_t size)
{
	phase = SKNO_NULL;

	FPReadRegistrationData(-1, &FPData);

	SKNOTxBuf[2] = (FPData.NumSKKO >> 24) & 0xFF;
	SKNOTxBuf[3] = (FPData.NumSKKO >> 16) & 0xFF;
	SKNOTxBuf[4] = (FPData.NumSKKO >> 8) & 0xFF;
	SKNOTxBuf[5] = FPData.NumSKKO & 0xFF;

	SKNOTxBuf[6] = (FPData.NumSKNO >> 24) & 0xFF;
	SKNOTxBuf[7] = (FPData.NumSKNO >> 16) & 0xFF;
	SKNOTxBuf[8] = (FPData.NumSKNO >> 8) & 0xFF;
	SKNOTxBuf[9] = FPData.NumSKNO & 0xFF;

	SKNOTxBuf[10] = command;

	SKNOTxBuf[11] = (size >> 8) & 0xFF; 	//data size
	SKNOTxBuf[12] = size & 0xFF;

	SKNOTxBuf[13] = 0; 						// number of packets
	SKNOTxBuf[14] = 1;

	SKNOTxBuf[15] = 0; 						// packet number
	SKNOTxBuf[16] = 1;

	uint16_t CRCData = CRC16_CCITT_CalcMass(SKNOTxBuf + 2, _SKNO_PACK_DATA_OFFSET + size - 2);

	SKNOTxBuf[size + _SKNO_PACK_DATA_OFFSET + 0] = (CRCData >> 8) & 0xFF; //CRC
	SKNOTxBuf[size + _SKNO_PACK_DATA_OFFSET + 1] = CRCData & 0xFF;

	uint16_t realSize = _SKNOInsert12(SKNOTxBuf, _SKNO_PACK_DATA_OFFSET + size + 2);

	SKNOTxBuf[0] = _SKNO_START; 				//packet start
	SKNOTxBuf[1] = _SKNO_STX;

	SKNOTxBuf[realSize + 0] = _SKNO_START; 	//packet end
	SKNOTxBuf[realSize + 1] = _SKNO_ETX;

	DebugSendNumWDescOneLine("\nSKNO PACKET: ", realSize+2);
	DebugSendChar('-');

	for(uint16_t i = 0; i < realSize + 2; i++)
	{
		_SKNOSendByte(SKNOTxBuf[i]);
		DebugSendNumWSpaceHex(SKNOTxBuf[i]);
	}

	DebugSendChar('\n');
}


/*******************************************************************************
* Function Name  : SKNOReadStatus
* Description    : Read SKNO status
*******************************************************************************/
int8_t SKNOReadStatus(uint8_t debugOutEn)
{
	phase = SKNO_NULL;

	_SKNOSendByte(_SKNO_START);
	_SKNOSendByte(_SKNO_REQ);

	SKNOSetTimeout(2000);

	while(SKNOTimeout)
	{
		if(phase & SKNO_REQ_RECEIVED)
		{
			phase &= ~(SKNO_REQ_RECEIVED); //clear SKNO_REQ_RECEIVED bit in phase variable

			SKNOStatus.busy 			= BitIsSet(_status, 0);
			SKNOStatus.cryptActive 		= BitIsSet(_status, 1);
			SKNOStatus.connection		= BitIsSet(_status, 2);
			SKNOStatus.blockedByEndCert = BitIsSet(_status, 3);
			SKNOStatus.blockedByZReports= BitIsSet(_status, 4);
			SKNOStatus.blockedByMemory	= BitIsSet(_status, 5);
			SKNOStatus.IDSuccessfull	= BitIsSet(_status, 6);
			SKNOStatus.ShiftOpened		= BitIsSet(_status, 7);

			SKNOStatus.TransferActive	= BitIsSet(_status, 8);
			SKNOStatus.UnsendedDocs		= BitIsSet(_status, 9);
			SKNOStatus.DocOverflow		= BitIsSet(_status, 10);
			SKNOStatus.SKNOAlive		= BitIsSet(_status, 11);
			SKNOStatusNum = _status;

			if(debugOutEn)
			{
				DebugSendString("\n===========SKNO @ REQ===================");
				if(SKNOStatus.busy) 			DebugSendString("BUSY");
				if(SKNOStatus.cryptActive)		DebugSendString("CRYPTED");
				if(SKNOStatus.connection)		DebugSendString("SERVER CONNECTION ACTIVE");
				if(SKNOStatus.blockedByEndCert)	DebugSendString("Prohibit by DATE");
				if(SKNOStatus.blockedByZReports)DebugSendString("Prohibit by unclosed Z");
				if(SKNOStatus.blockedByMemory)	DebugSendString("Prohibit by MEM Overflow");
				if(SKNOStatus.IDSuccessfull)	DebugSendString("IDentification SUCCESS");
				if(SKNOStatus.ShiftOpened)		DebugSendString("Z is OPENED");

				if(SKNOStatus.TransferActive)	DebugSendString("TRANSFER ACTIVE");
				if(SKNOStatus.UnsendedDocs)		DebugSendString("UNSENDED DOCS in memory");
				if(SKNOStatus.DocOverflow)		DebugSendString("OVERSIZED DOCUMENT");
				if(SKNOStatus.SKNOAlive)		DebugSendString("SKNO OK!!!");
			}

			return STATUS_SUCCESSFULL;
		}

		if(phase == SKNO_ERROR)
		{
			if(debugOutEn) DebugSendString("\nEOT ERROR!");

			delay_ms(200);
			_SKNOSendAck();
			return STATUS_FAIL_COM;
		}
	}

	DebugSendString("\n SKNO @@@ REQ @@@ timeout!");
	return STATUS_NO_ANSWER;
}


/*******************************************************************************
* Function Name  : SKNOSendID
* Description    : SKNO identification operation
*******************************************************************************/
int8_t SKNOSendID()
{
	uint8_t failCounter = 0;

	if(SKNOWaitReadyState() == STATUS_BUSY)
		return STATUS_BUSY;

	ClearBuffer(SKNOTxBuf, 100, 0);

	FPReadRegistrationData(-1, &FPData);

	itoa_zeros(FPReadNKKM(), SKNOTxBuf + _SKNO_PACK_DATA_OFFSET, 13);							//KKM number
	strcatnum(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 13, (uint8_t*)
		/*FPData.systemName*/"0000000000\xCa\xe0\xf1\xe1\xe8-03\xCc\xD4" /*�����-03��*/, 20); 	//SYS NAME

	SKNOTxBuf[_SKNO_PACK_DATA_OFFSET + 13 + 20 + 0] = (FPData.NumSubsc >> 24) & 0xFF; 											//UNP
	SKNOTxBuf[_SKNO_PACK_DATA_OFFSET + 13 + 20 + 1] = (FPData.NumSubsc >> 16) & 0xFF;
	SKNOTxBuf[_SKNO_PACK_DATA_OFFSET + 13 + 20 + 2] = (FPData.NumSubsc >> 8) & 0xFF;
	SKNOTxBuf[_SKNO_PACK_DATA_OFFSET + 13 + 20 + 3] = FPData.NumSubsc & 0xFF;

SKNOSendIDAgain:

	ClearBuffer(SKNORxBuf, 100, 0);
	SKNORxCnt = 0;

	_SKNOSendPacket(_SKNO_COM_ID, 37);

	SKNOTimeout = 2000; //set timeout
	while(phase != SKNO_PKT_ACKED && phase != SKNO_PKT_NACKED && SKNOTimeout);
	if(SKNOTimeout == 0 || phase == SKNO_PKT_NACKED)
	{
		if(phase == SKNO_PKT_NACKED)
			DebugSendString("PKT NACKED....");
		else
			DebugSendString("PKT ACKED/NACKED TIMEOUT....");
		return STATUS_ERROR;
	}

	ClearBuffer(SKNORxBuf, 100, 0);
	delay_ms(200);

CheckAnsw:
	SKNOReadStatus(0);
	if(SKNOStatus.busy)
	{
		delay_ms(50);
		goto CheckAnsw;
	}

	if(phase == SKNO_ERROR) //EOT received
	{
		DebugSendString("ERROR EOT!");
	}
	else
	{
		SKNOTimeout = 2000;

		while(phase != SKNO_PKT_RECEIVED && SKNOTimeout);

		if(SKNOTimeout == 0)
		{
			DebugSendString("PKT RECEIVING TIMEOUT....");
		}
		else
		{
			if(_SKNO_CRC16Compare(SKNORxBuf, SKNODataSize - 2) == STATUS_SUCCESSFULL)
			{
				_SKNOSendAck();

				DebugSendString("ID PKT RECEIVED!!! >>NO ERRORS!!!>>>>");

				if(SKNOStatus.IDSuccessfull)
					DebugSendString("ID successfull");
				else
					DebugSendString("ID UNsuccessfull");

				return STATUS_SUCCESSFULL;
			}
			else
			{
				_SKNOSendNack();

				DebugSendString("ID PKT RECEIVED  With errors");
				DebugSendNumWDesc(">>DATA SIZE = ", SKNODataSize);

				for(uint8_t i = 0; i < SKNODataSize; i++)
					DebugSendNumWSpaceHex(SKNORxBuf[i]);

				if(++failCounter > 2)
				{
					DebugSendString("ID Packet read failed > 3 times ------------------------------->");
					return STATUS_ERROR;
				}
				else
					goto SKNOSendIDAgain;
			}
		}
	}

	return STATUS_ERROR;
}


/*******************************************************************************
* Function Name  : SKNOReadDateTime
* Description    : Read current date & time from the SKNO
*******************************************************************************/
int8_t SKNOReadDateTime()
{
	uint8_t failCounter = 0;

	if(SKNOWaitReadyState() == STATUS_BUSY)
		return STATUS_BUSY;

SKNOReadDateTimeAgain:

	ClearBuffer(SKNOTxBuf, 100, 0);
	_SKNOSendPacket(_SKNO_COM_TIME_DATE, 0);

	SKNOTimeout = 2000; //set timeout

	while(phase != SKNO_PKT_ACKED && phase != SKNO_PKT_NACKED && SKNOTimeout);
	if(SKNOTimeout == 0 || phase == SKNO_PKT_NACKED)
	{
		if(phase == SKNO_PKT_NACKED)
			DebugSendString("PKT NACKED....");
		else
			DebugSendString("PKT ACKED/NACKED TIMEOUT....");
		return STATUS_ERROR;
	}

	delay_ms(200);

CheckAnsw:
	SKNOReadStatus(0);
	if(SKNOStatus.busy)
	{
		delay_ms(50);
		goto CheckAnsw;
	}

	if(phase == SKNO_ERROR) //EOT received
	{
		DebugSendString("ERROR EOT!");
	}
	else
	{
		SKNOTimeout = 2000;

		while(phase != SKNO_PKT_RECEIVED && SKNOTimeout);

		if(SKNOTimeout == 0)
		{
			DebugSendString("PKT RECEIVING TIMEOUT....");
		}
		else
		{
			RTC_TimeDateTypeDef SKNOTimeDate;

			if(_SKNO_CRC16Compare(SKNORxBuf, SKNODataSize - 2) == STATUS_SUCCESSFULL)
			{
				_SKNOSendAck();

				DebugSendString("PKT RECEIVED!!! >>NO ERRORS!!!>>>>");

				SKNOTimeDate.year 	= SKNORxBuf[_SKNO_RXPKT_DATA_OFFSET + 0];
				SKNOTimeDate.month 	= SKNORxBuf[_SKNO_RXPKT_DATA_OFFSET + 1];
				SKNOTimeDate.date 	= SKNORxBuf[_SKNO_RXPKT_DATA_OFFSET + 2];
				SKNOTimeDate.hour 	= SKNORxBuf[_SKNO_RXPKT_DATA_OFFSET + 3];
				SKNOTimeDate.minute = SKNORxBuf[_SKNO_RXPKT_DATA_OFFSET + 4];
				SKNOTimeDate.second = SKNORxBuf[_SKNO_RXPKT_DATA_OFFSET + 5];

				DebugSendTD(&SKNOTimeDate);

				return STATUS_SUCCESSFULL;
			}
			else
			{
				_SKNOSendNack();

				DebugSendString("PKT RECEIVED  With errors");
				DebugSendNumWDesc(">>DATA SIZE = ", SKNODataSize);

				for(uint8_t i = 0; i < SKNODataSize; i++)
					DebugSendNumWSpaceHex(SKNORxBuf[i]);

				if(++failCounter>2)
				{
					DebugSendString("Packet read failed > 3 times ------------------------------->");
					return STATUS_ERROR;
				}
				else
					goto SKNOReadDateTimeAgain;
			}
		}
	}

	return STATUS_ERROR;
}


/*******************************************************************************
* Function Name  : SKNOWaitReadyState
* Description    : Wait until SKNO's busy flag is set (for 5 seconds)
*******************************************************************************/
int8_t SKNOWaitReadyState()
{
	for(uint8_t i = 0; i <= 20; i++)
	{
		SKNOReadStatus(0);

		if(SKNOStatus.busy == 0)
			break;

		if(i == 20 && SKNOStatus.busy) //5 sec = .250ms * 20 times
		{
			DebugSendString("SKNO is BUSY more than 5 sec >>>>>>>>>>>");
			return STATUS_BUSY;
		}

		delay_ms(250);
	}

	return STATUS_SUCCESSFULL;
}


/*******************************************************************************
* Function Name  : SKNOOpenShift
* Description    : Open new shift in the SKNO
*******************************************************************************/
int8_t SKNOOpenShift()
{
	uint8_t failCounter = 0;

	if(SKNOWaitReadyState() == STATUS_BUSY)
		return STATUS_BUSY;

	SKNOOpenShiftAgain:

	ClearBuffer(SKNOTxBuf, 100, 0);
	_SKNOSendPacket(_SKNO_COM_OPEN_SHIFT, 0);

	SKNOTimeout = 2000; //set timeout

	while(phase != SKNO_PKT_ACKED && phase != SKNO_PKT_NACKED && SKNOTimeout);
	if(SKNOTimeout == 0 || phase == SKNO_PKT_NACKED)
	{
		if(phase == SKNO_PKT_NACKED)
			DebugSendString("PKT NACKED....");
		else
			DebugSendString("PKT ACKED/NACKED TIMEOUT....");
		return STATUS_ERROR;
	}

	delay_ms(200);

	if(SKNOWaitReadyState() == STATUS_BUSY)
		return STATUS_BUSY;

	if(phase == SKNO_ERROR) //EOT received
	{
		DebugSendString("ERROR EOT!");
	}
	else
	{
		SKNOTimeout = 2000;
		while(phase != SKNO_PKT_RECEIVED && SKNOTimeout);

		if(SKNOTimeout == 0)
		{
			DebugSendString("PKT RECEIVING TIMEOUT....");
		}
		else
		{
			if(_SKNO_CRC16Compare(SKNORxBuf, SKNODataSize - 2) == STATUS_SUCCESSFULL)
			{
				_SKNOSendAck(); //Send Packet ACK

				DebugSendString("OPEN SHIFT PKT RECEIVED!!! >>NO ERRORS!!!>>>>");

				if(SKNOStatus.ShiftOpened)
					DebugSendString("Shift OPEN successfull");
				else
					DebugSendString("Shift OPEN UNsuccessfull");

				return STATUS_SUCCESSFULL;
			}
			else
			{
				_SKNOSendNack(); //Send Packet NACK

				DebugSendString("PKT RECEIVED  With errors");
				DebugSendNumWDesc(">>DATA SIZE = ", SKNODataSize);

				for(uint8_t i = 0; i < SKNODataSize; i++)
					DebugSendNumWSpaceHex(SKNORxBuf[i]);

				if(++failCounter > 2)
				{
					DebugSendString("Packet read failed > 3 times ------------------------------->");
					return STATUS_ERROR;
				}
				else
					goto SKNOOpenShiftAgain;
			}
		}
	}

	return STATUS_ERROR;
}


/*******************************************************************************
* Function Name  : _SKNOSendCheck
* Description    : Send document to the SKNO: Check
*******************************************************************************/
static uint16_t _SKNOSendCheck()
{
	SKNOTxBuf[_SKNO_PACK_DATA_OFFSET] = 0;											//1 check

	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+1, FPReadNKKM()); 					//4 KKM number

	strcatnum(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+5, (uint8_t*)"Kassir 1 Unknown", 16); 	//16 kassir name

	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+21, 1); 							//4 number of document

	WriteTimeDateBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+25, RTCGetTimeDate()); 			//6 current timedate

	strcatnum(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+31, (uint8_t*)"BYR", 3); 				//3 CURRENCY

	SKNOTxBuf[_SKNO_PACK_DATA_OFFSET + 40] = 48; 										//7 service operation

	SKNOTxBuf[_SKNO_PACK_DATA_OFFSET + 41] = 0xE8;										//3 number of goods/services = 1.00
	SKNOTxBuf[_SKNO_PACK_DATA_OFFSET + 42] = 0x03;

	WriteFracBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+44, 10050); 							//6 total sum

	WriteFracBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+50, 0); 								//6 discount sum

	WriteFracBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+56, 10050); 							//6 total sum within the document

	WriteFracBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+62, 0); 								//6 discount sum within the document

	WriteFracBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+68, 10050);							//6 total sum to pay

	WriteFracBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+74, 0); 								//6 total sum to pay by credit card

	WriteFracBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+80, 10050); 							//6 total sum to pay cash

	WriteFracBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+86, 0); 								//6 total sum to pay by other payments

	WriteFracBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+92, 0); 								//6 reserved

	return _SKNO_PACK_DATA_OFFSET + 98;
}


/*******************************************************************************
* Function Name  : _SKNOSendDeposit
* Description    : Send document to the SKNO: Deposit
*******************************************************************************/
static uint16_t _SKNOSendDeposit()
{
	SKNOTxBuf[_SKNO_PACK_DATA_OFFSET] = 1;											//1 deposit

	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+1, FPReadNKKM()); 					//4 KKM number

	strcatnum(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+5, (uint8_t*)"Kassir 1 Unknown", 16); 	//16 kassir name

	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+21, 1); 							//4 number of document

	WriteTimeDateBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+25, RTCGetTimeDate()); 			//6 current timedate

	strcatnum(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+31, (uint8_t*)"BYR", 3); 				//3 CURRENCY

	WriteFracBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+34, 0); 								//6 deposit sum

	WriteFracBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+40, 0); 								//6 reserved
	WriteFracBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+46, 0); 								//6 reserved

	return _SKNO_PACK_DATA_OFFSET + 52;
}


/*******************************************************************************
* Function Name  : _SKNOSendWithdrawal
* Description    : Send document to the SKNO: Withdrawal
*******************************************************************************/
static uint16_t _SKNOSendWithdrawal()
{
	SKNOTxBuf[_SKNO_PACK_DATA_OFFSET] = 2;											//1 withdrawal

	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+1, FPReadNKKM()); 					//4 KKM number

	strcatnum(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+5, (uint8_t*)"Kassir 1 Unknown", 16); 	//16 kassir name

	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+21, 1); 							//4 number of document

	WriteTimeDateBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+25, RTCGetTimeDate()); 			//6 current timedate

	strcatnum(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+31, (uint8_t*)"BYR", 3); 				//3 CURRENCY

	WriteFracBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+34, 0); 								//6 withdraw sum

	WriteFracBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+40, 0); 								//6 reserved
	WriteFracBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+46, 0); 								//6 reserved

	return _SKNO_PACK_DATA_OFFSET + 52;
}


/*******************************************************************************
* Function Name  : _SKNOSendRefund
* Description    : Send document to the SKNO: Refund
*******************************************************************************/
static uint16_t _SKNOSendRefund()
{
	SKNOTxBuf[_SKNO_PACK_DATA_OFFSET] = 3;											//1 refund

	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+1, FPReadNKKM()); 					//4 KKM number

	strcatnum(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+5, (uint8_t*)"Kassir 1 Unknown", 16); 	//16 kassir name

	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+21, 1); 							//4 number of document

	WriteTimeDateBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+25, RTCGetTimeDate()); 			//6 current timedate

	strcatnum(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+31, (uint8_t*)"BYR", 3); 				//3 CURRENCY

	SKNOTxBuf[_SKNO_PACK_DATA_OFFSET + 40] = 48; 										//7 service

	SKNOTxBuf[_SKNO_PACK_DATA_OFFSET + 41] = 0xE8;										//3 number of goods/services = 1.00
	SKNOTxBuf[_SKNO_PACK_DATA_OFFSET + 42] = 0x03;

	WriteFracBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+44, 0); 								//6 refund sum

	WriteFracBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+50, 0); 								//6 refund sum cash
	WriteFracBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+56, 0); 								//6 refund sum cashless

	return _SKNO_PACK_DATA_OFFSET + 62;
}


/*******************************************************************************
* Function Name  : _SKNOSendAnnul
* Description    : Send document to the SKNO: Annulir
*******************************************************************************/
static uint16_t _SKNOSendAnnul()
{
	SKNOTxBuf[_SKNO_PACK_DATA_OFFSET] = 4;											//1 annulir

	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+1, FPReadNKKM()); 					//4 KKM number

	strcatnum(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+5, (uint8_t*)"Kassir 1 Unknown", 16); 	//16 kassir name

	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+21, 1); 							//4 number of document

	WriteTimeDateBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+25, RTCGetTimeDate()); 			//6 current timedate

	strcatnum(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+31, (uint8_t*)"BYR", 3); 				//3 CURRENCY

	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+34, 1);								//4 number of annul doc
	WriteFracBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+38, 0); 								//6 annul sum

	WriteFracBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+44, 0); 								//6 reserved
	WriteFracBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET+50, 0); 								//6 reserved

	return _SKNO_PACK_DATA_OFFSET + 56;
}


/*******************************************************************************
* Function Name  : SKNOSendDoc
* Description    : Send document to the SKNO
* Input			 : Command is the type of document
*******************************************************************************/
int8_t SKNOSendDoc(uint8_t command)
{
	uint8_t failCounter = 0;
	uint16_t (*pFunction[5])() =
	{_SKNOSendCheck, _SKNOSendDeposit, _SKNOSendWithdrawal, _SKNOSendRefund, _SKNOSendAnnul};

	if(SKNOWaitReadyState() == STATUS_BUSY)
		return STATUS_BUSY;

	if(SKNOStatus.ShiftOpened == 0)
	{
		DebugSendString("Shift is closed >> You can't exec this command >>>");
		return STATUS_FAIL_COM;
	}

SKNOSendDocAgain:

	ClearBuffer(SKNOTxBuf, 120, 0);

	_SKNOSendPacket(_SKNO_COM_SEND_DOC, (*pFunction[command])());

	SKNOTimeout = 2000; //set timeout

	while(phase != SKNO_PKT_ACKED && phase != SKNO_PKT_NACKED && SKNOTimeout);
	if(SKNOTimeout == 0 || phase == SKNO_PKT_NACKED)
	{
		if(phase == SKNO_PKT_NACKED)
			DebugSendString("PKT NACKED....");
		else
			DebugSendString("PKT ACKED/NACKED TIMEOUT....");
		return STATUS_ERROR;
	}

	delay_ms(200);

	if(SKNOWaitReadyState() == STATUS_BUSY)
		return STATUS_BUSY;

	if(phase == SKNO_ERROR) //EOT received
	{
		DebugSendString("ERROR EOT!");
	}
	else
	{
		SKNOTimeout = 2000;

		while(phase != SKNO_PKT_RECEIVED && SKNOTimeout);

		if(SKNOTimeout == 0)
		{
			DebugSendString("PKT RECEIVING TIMEOUT....");
		}
		else
		{
			if(_SKNO_CRC16Compare(SKNORxBuf, SKNODataSize - 2) == STATUS_SUCCESSFULL)
			{
				_SKNOSendAck();

				DebugSendString("DOCUMENT SEND PKT RECEIVED!!! >>NO ERRORS!!!>>>>");

				DebugSendString("UID = ");
				for(uint8_t i = 15; i < SKNODataSize-2; i++)
					DebugSendNumWSpaceHex(SKNORxBuf[i]);

				//PrintCode128(SKNORxBuf+15);
				PrintQrCode(SKNORxBuf+15, 12);

				return STATUS_SUCCESSFULL;
			}
			else
			{
				_SKNOSendNack();

				DebugSendString("PKT RECEIVED  With errors");
				DebugSendNumWDesc(">>DATA SIZE = ", SKNODataSize);

				for(uint8_t i = 0; i < SKNODataSize; i++)
					DebugSendNumWSpaceHex(SKNORxBuf[i]);

				if(++failCounter > 2)
				{
					DebugSendString("Packet DOCUMENT SEND failed > 3 times ------------------------------->");
					return STATUS_ERROR;
				}
				else
					goto SKNOSendDocAgain;
			}
		}
	}

	return STATUS_ERROR;
}


/*******************************************************************************
* Function Name  : SKNOGetUID
* Description    : Get unique ID again
*******************************************************************************/
int8_t SKNOGetUID()
{
	uint8_t failCounter = 0;

	if(SKNOWaitReadyState() == STATUS_BUSY)
		return STATUS_BUSY;

	if(SKNOStatus.TransferActive == 0)
	{
		DebugSendString("All docs are completed >> You can't exec this command >>>");
		return STATUS_FAIL_COM;
	}

SKNOGetUIDAgain:

	ClearBuffer(SKNOTxBuf, 100, 0);
	_SKNOSendPacket(_SKNO_COM_GET_UNID, 0);

	SKNOTimeout = 2000; //set timeout

	while(phase != SKNO_PKT_ACKED && phase != SKNO_PKT_NACKED && SKNOTimeout);
	if(SKNOTimeout == 0 || phase == SKNO_PKT_NACKED)
	{
		if(phase == SKNO_PKT_NACKED)
			DebugSendString("PKT NACKED....");
		else
			DebugSendString("PKT ACKED/NACKED TIMEOUT....");
		return STATUS_ERROR;
	}

	delay_ms(200);

	if(SKNOWaitReadyState() == STATUS_BUSY)
		return STATUS_BUSY;

	if(phase == SKNO_ERROR) //EOT received
	{
		DebugSendString("ERROR EOT!");
	}
	else
	{
		SKNOTimeout = 2000;

		while(phase != SKNO_PKT_RECEIVED && SKNOTimeout);

		if(SKNOTimeout == 0)
		{
			DebugSendString("PKT RECEIVING TIMEOUT....");
		}
		else
		{
			if(_SKNO_CRC16Compare(SKNORxBuf, SKNODataSize - 2) == STATUS_SUCCESSFULL)
			{
				_SKNOSendAck();

				DebugSendString("GET UID PKT RECEIVED!!! >>NO ERRORS!!!>>>>");

				DebugSendString("UID = ");
				for(uint8_t i = 15; i < SKNODataSize-2; i++)
					DebugSendNumWSpaceHex(SKNORxBuf[i]);

				PrintQrCode(SKNORxBuf+15, 12);

				return STATUS_SUCCESSFULL;
			}
			else
			{
				_SKNOSendNack();

				DebugSendString("GET UID PKT RECEIVED  With errors");
				DebugSendNumWDesc(">>DATA SIZE = ", SKNODataSize);

				for(uint8_t i = 0; i < SKNODataSize; i++)
					DebugSendNumWSpaceHex(SKNORxBuf[i]);

				if(++failCounter > 2)
				{
					DebugSendString("Packet GET UID failed > 3 times ------------------------------->");
					return STATUS_ERROR;
				}
				else
					goto SKNOGetUIDAgain;
			}
		}
	}

	return STATUS_ERROR;
}


/*******************************************************************************
* Function Name  : SKNOCloseShift
* Description    : Close shift
*******************************************************************************/
int8_t SKNOCloseShift()
{
	uint8_t failCounter = 0;

	if(SKNOWaitReadyState() == STATUS_BUSY)
		return STATUS_BUSY;

	if(SKNOStatus.ShiftOpened == 0)
	{
		DebugSendString("Shift is closed >> You can't exec this command >>>");
		return STATUS_FAIL_COM;
	}

	FPReadRegistrationData(-1, &FPData);

SKNOCloseShiftAgain:

	ClearBuffer(SKNOTxBuf, 150, 0);

	SKNOTxBuf[_SKNO_PACK_DATA_OFFSET] = 20;									//1 Shift close

	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 1, FPData.NumSubsc); 		//4 UNP number

	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 5, FPReadNKKM()); 		//4 KKM number

	WriteTimeDateBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 9, RTCGetTimeDate());	//6 open shift

	WriteTimeDateBuf(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 15, RTCGetTimeDate());	//6 close shift

	WriteBuf16MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 21, 1);					//2 number of Z-report

	WriteBuf16MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 23, 5);					//2 number of tickets

	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 25, 1); 					//4 Number of first ticket

	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 29, 5); 					//4 Number of last ticket

	SKNOTxBuf[_SKNO_PACK_DATA_OFFSET + 33] = 1;									//1 Number of Currencies

	strcatnum(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 34, (uint8_t*) "BYR", 3); 	//3 CURRENCY 1

	WriteBuf16MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 37, 5);					//2 number of tickets CURR1
	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 39, 1); 					//6 summ sellings
	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 45, 0); 					//6 summ sellings cashless
	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 51, 10060); 				//6 summ sellings cash

	WriteBuf16MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 57, 0);					//2 number of returns CURR1
	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 59, 0); 					//6 summ of returns

	WriteBuf16MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 65, 0);					//2 number of depositions CURR1
	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 67, 0); 					//6 summ of depositions

	WriteBuf16MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 73, 0);					//2 number of withdraws CURR1
	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 75, 0); 					//6 summ of withdraws

	WriteBuf16MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 81, 0);					//2 number of cancellations CURR1
	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 83, 0); 					//6 summ of cancellations

	WriteBuf16MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 89, 0);					//2 number of annul CURR1
	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 91, 0); 					//6 summ of annul

	WriteBuf16MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 97, 0);					//2 number of corrections CURR1
	WriteBuf32MSB(SKNOTxBuf + _SKNO_PACK_DATA_OFFSET + 99, 0); 					//6 summ of corrections

	_SKNOSendPacket(_SKNO_COM_CLOSE_SHIFT, 105);

	SKNOTimeout = 2000; //set timeout

	while(phase != SKNO_PKT_ACKED && phase != SKNO_PKT_NACKED && SKNOTimeout);
	if(SKNOTimeout == 0 || phase == SKNO_PKT_NACKED)
	{
		if(phase == SKNO_PKT_NACKED)
			DebugSendString("PKT NACKED....");
		else
			DebugSendString("PKT ACKED/NACKED TIMEOUT....");
		return STATUS_ERROR;
	}

	delay_ms(200);

	if(SKNOWaitReadyState() == STATUS_BUSY)
		return STATUS_BUSY;

	if(phase == SKNO_ERROR) //EOT received
	{
		DebugSendString("ERROR EOT!");
	}
	else
	{
		SKNOTimeout = 2000;

		while(phase != SKNO_PKT_RECEIVED && SKNOTimeout);

		if(SKNOTimeout == 0)
		{
			DebugSendString("PKT RECEIVING TIMEOUT....");
		}
		else
		{
			if(_SKNO_CRC16Compare(SKNORxBuf, SKNODataSize - 2) == STATUS_SUCCESSFULL)
			{
				_SKNOSendAck();

				DebugSendString("CLOSE SHIFT PKT RECEIVED!!! >>NO ERRORS!!!>>>>");

//				if(SKNOStatus.ShiftOpened)
//					DebugSendString("Shift CLOSE UNsuccessfull");
//				else
//					DebugSendString("Shift CLOSE successfull");

				DebugSendString("UID = ");
				for(uint8_t i = 15; i < SKNODataSize-2; i++)
					DebugSendNumWSpaceHex(SKNORxBuf[i]);

				PrintQrCode(SKNORxBuf+15, 12);

				return STATUS_SUCCESSFULL;
			}
			else
			{
				_SKNOSendNack();

				DebugSendString("PKT RECEIVED  With errors");
				DebugSendNumWDesc(">>DATA SIZE = ", SKNODataSize);

				for(uint8_t i = 0; i < SKNODataSize; i++)
					DebugSendNumWSpaceHex(SKNORxBuf[i]);

				if(++failCounter > 2)
				{
					DebugSendString("Packet read failed > 3 times ------------------------------->");
					return STATUS_ERROR;
				}
				else
					goto SKNOCloseShiftAgain;
			}
		}
	}

	return STATUS_ERROR;
}


/*******************************************************************************
* Function Name  : SKNOWaitConnection
* Description    : Wait until Connection with server is present
*******************************************************************************/
int8_t SKNOWaitConnection()
{
	uint8_t pos = 7, cnt = 0;

	while(SKNOStatus.connection == 0)
	{
		uint8_t dddp[] = { "\x91\xae\xa5\xa4\xa8\xad.   " /*������.   */};
		dddp[pos] = '>';
		DisplayString(dddp);

		delay_ms(30);
		if(++cnt>= 10)
		{
			if(++pos >= 10)
				pos = 7;
			cnt = 0;
		}

		if(KeyboardScan() == KEY_SB)
			return STATUS_INTERRUPTED;

		SKNOReadStatus(1);
	}

	SoundBeepSuccess();
	DisplayString((uint8_t*)"\x91\xae\xa5\xa4\xa8\xad.\x93\xe1\xe2" /*������.���*/);
	delay_ms(1000);

	return STATUS_SUCCESSFULL;
}
