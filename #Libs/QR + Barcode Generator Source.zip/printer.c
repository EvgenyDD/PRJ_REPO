/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_tim.h"
#include "printer.h"
#include "macros.h"
#include "misc.h"
#include <stdbool.h>
#include "string.h"
#include "Common.h"
#include "display.h"

#include "qrencode.h"
#include "code128.h"


/* THIS IS PRINTER DRIVER
 * The line length is 384 pixels
 * each dot is 0.125 mm
 * Printer speed is 640 lines/sec
 *
 * The font is 5x8 pixels
 * The space is 1 pixel width and 5 pixels hight
 * There is 27(PRINTER_LINE) chars (5x8) in one line
 *
 * The density of print is regulated by lenth of burn pulse:
 * 0 - 1155us
 * 1 - 2019us
 * 2 - 2885us
 * 3 - 3752us
 * 4 - 4618us
 * 5 - 5482us
 * 6 - 6350us
 * 7 - 7213us
 * 8 - 8075us
 */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
static uint8_t phase = 0;
uint8_t printDensity = 3; //0 - is invisible, 8 - max bright
static uint8_t printBuffer[48] = { 0 };

volatile static bool isPrinting = false;
volatile static bool stepIsActive = false;

/* Extern variables ----------------------------------------------------------*/
extern const uint8_t font5x8[];
extern uint8_t FISK_SYMBOL[5 * 8];

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*******************************************************************************
 * Function Name  : PrinterInit
 * Description    : Initialize printer module
 *******************************************************************************/
void PrinterInit()
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD,
		ENABLE);

	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5
		| GPIO_Pin_15 | GPIO_Pin_14;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	// Timers for delay functions
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2 | RCC_APB1Periph_TIM4, ENABLE);

	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	TIM_TimeBaseStructure.TIM_Period = 65535;
	TIM_TimeBaseStructure.TIM_Prescaler = 9 - 1;
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Down;

	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);

	TIM_SelectOnePulseMode(TIM2, TIM_OPMode_Single);
	TIM_SelectOnePulseMode(TIM4, TIM_OPMode_Single);

	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 4; //?
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;
	NVIC_Init(&NVIC_InitStructure);

	TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
	NVIC_EnableIRQ(TIM2_IRQn);

	TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);
	NVIC_EnableIRQ(TIM4_IRQn);
}


/*******************************************************************************
 * Function Name  : _PrinterRotate
 * Description    : Move the paper
 * Note			  : The function not implement enable/disable signals
 *******************************************************************************/
static void _PrinterRotate(uint32_t steps, uint8_t direction)
{
	for(uint32_t i = 0; i < steps; i++)
	{
		// increment/decrement phase of step motor
		if(direction == PRINTER_FORWARD)
		{
			if(++phase >= 4)
				phase = 0;
		}
		else
		{
			if(--phase >= 4)
				phase = 3;
		}

		// set motor coils
		GPIO_WriteBit(GPIOC, GPIO_Pin_0, phase == 1 || phase == 2);
		GPIO_WriteBit(GPIOC, GPIO_Pin_1, BitIsReset(phase, 1));

		// wait some time while step motor is moving
		stepIsActive = true;
		TIM4->CNT = 7500; // 2512 us
		TIM_Cmd(TIM4, ENABLE);
		while(stepIsActive);
	}
}


/*******************************************************************************
 * Function Name  : PrinterStep
 * Description    : Make motor move the paper (value in millimeters)
 *******************************************************************************/
void PrinterStep(uint32_t num)
{
	GPIO_SetBits(GPIOB, GPIO_Pin_5);
	GPIO_SetBits(GPIOC, GPIO_Pin_2 | GPIO_Pin_3);

	_PrinterRotate((num * 63) >> 2, PRINTER_FORWARD);

	GPIO_ResetBits(GPIOC, GPIO_Pin_2 | GPIO_Pin_3);
	GPIO_ResetBits(GPIOB, GPIO_Pin_5);
}


/*******************************************************************************
 * Function Name  : PrinterStep
 * Description    : Make motor move the paper (value in millimeters)
 *******************************************************************************/
void PrinterStepInverse(uint32_t num)
{
	GPIO_SetBits(GPIOB, GPIO_Pin_5);
	GPIO_SetBits(GPIOC, GPIO_Pin_2 | GPIO_Pin_3);

	_PrinterRotate((num * 63) >> 2, PRINTER_REVERSE);

	GPIO_ResetBits(GPIOC, GPIO_Pin_2 | GPIO_Pin_3);
	GPIO_ResetBits(GPIOB, GPIO_Pin_5);
}


/*******************************************************************************
 * Function Name  : PrintString
 * Description    : Make printBuffer transfer to paper by setting burning dots
 *******************************************************************************/
static void _PrinterPulse()
{
	TIM2->CNT = printDensity * 6924 + 9237;
	TIM_Cmd(TIM2, ENABLE);
	GPIO_ResetBits(GPIOC, GPIO_Pin_14 | GPIO_Pin_15); //set burning dots
	isPrinting = true;
}


/*******************************************************************************
 * Function Name  : _PrinterPutLine
 * Description    : Print one line on paper
 *******************************************************************************/
static void _PrinterPutLine(uint8_t dots)
{
	while(isPrinting);

	for(uint16_t i = 0; i < 384; i++)
	{
		if(BitIsSet(printBuffer[i/8], i%8))
			GPIOA->BRR = GPIO_Pin_8;
		else
			GPIOA->BSRR = GPIO_Pin_8;

		GPIOC->BRR = GPIO_Pin_4;
		GPIOC->BSRR = GPIO_Pin_4;
	}

	GPIOC->BSRR = GPIO_Pin_5;
	GPIOC->BRR = GPIO_Pin_5;
	_PrinterPulse();

	_PrinterRotate(dots, PRINTER_FORWARD);
}


/*******************************************************************************
 * Function Name  : PrintStringLine
 * Description    : Print one string on paper (max PRINTER_LINE chars)
 *******************************************************************************/
void PrintStringLine(uint8_t * string)
{
	GPIO_SetBits(GPIOB, GPIO_Pin_5);
	GPIO_SetBits(GPIOC, GPIO_Pin_2 | GPIO_Pin_3);

	uint16_t len = strlen(string);

	_PrinterRotate(5 * 1, PRINTER_FORWARD); // 5 dots at top

	for(uint8_t i = 0; i < 8; i++)
	{
		PrinterResetBuffer();
		uint8_t fiskJ = 0, fiskMassPtr = 0;

		for(uint16_t j = 0; j < 192 && j < ((5 + 2) * len + (fiskJ ? (40 - (5 + 2)) : 0)); j++)
		{
			uint16_t charPos = j / (5 + 2), charOffset = j % (5 + 2);

			uint8_t t;
			if(fiskJ == 0)
				t = string[charPos];

			if(t != '\xFF' && fiskJ == 0) //can't print anything after FISK SYMBOL
			{
				if(charOffset == 5 || charOffset == 6)
				{
					BitWrite(0, printBuffer[j*2/8], (j*2)%8);
					BitWrite(0, printBuffer[(j*2+1)/8], (j*2+1)%8);
				}
				else
				{
					BitWrite(BitIsSet(font5x8[5*(t-32)+charOffset], i), printBuffer[j*2/8], (j*2)%8);
					BitWrite(BitIsSet(font5x8[5*(t-32)+charOffset], i), printBuffer[(j*2+1)/8], (j*2+1)%8);
				}
			}
			else //fisk symbol
			{
				if(fiskJ == 0)
				{
					fiskJ = j;
					fiskMassPtr = j;
				}

				BitWrite(BitIsSet(FISK_SYMBOL[(((j-fiskJ)/8)*8)+i], 7-((j-fiskJ)%8)), printBuffer[fiskMassPtr*2/8],
					(fiskMassPtr*2)%8);
				BitWrite(BitIsSet(FISK_SYMBOL[(((j-fiskJ)/8)*8)+i], 7-((j-fiskJ)%8)), printBuffer[(fiskMassPtr*2+1)/8],
					(fiskMassPtr*2+1)%8);

				if(((j - fiskJ) % 8) != 0) //first bit is null in FISK MASSIVE
					fiskMassPtr++;
			}
		}

		_PrinterPutLine(5);
	}

	_PrinterRotate(5 * 1, PRINTER_FORWARD); // 5 dots at bottom

	GPIO_ResetBits(GPIOC, GPIO_Pin_2 | GPIO_Pin_3);
	GPIO_ResetBits(GPIOB, GPIO_Pin_5);
}


/*******************************************************************************
 * Function Name  : PrintStringCentered
 * Description    : Print string on paper at center
 *******************************************************************************/
void PrintStringCentered(uint8_t* string)
{
	uint8_t len = strlen(string);

	if(len >= PRINTER_LINE)
		PrintStringLine(string);
	else
	{
		uint8_t temp[28];
		ClearBuffer(temp, PRINTER_LINE, ' ');
		temp[PRINTER_LINE] = '\0';

		strcatNum2(temp, string, (PRINTER_LINE - len) / 2);
		PrintStringLine(temp);
	}
}


/*******************************************************************************
 * Function Name  : PrintString
 * Description    : Print string on paper WITH CARRY
 *******************************************************************************/
void PrintString(uint8_t* string)
{
	uint16_t len = strlen(string);
	uint16_t numOfStr = len / PRINTER_LINE;

	if(len <= PRINTER_LINE)
		PrintStringLine(string);
	else
	{
		uint8_t temp[PRINTER_LINE + 1] = { '\0' };

		for(uint8_t i = 0; i < len / PRINTER_LINE; i++)
		{
			for(uint8_t k = 0; k < PRINTER_LINE; k++)
				temp[k] = string[i * PRINTER_LINE + k];

			PrintStringLine(temp);
		}
		if(len % PRINTER_LINE)
		{
			for(uint8_t i = 0; i < PRINTER_LINE; i++)
				temp[i] = '\0';

			for(uint8_t k = 0; k < (len % PRINTER_LINE); k++)
				temp[k] = string[(numOfStr * PRINTER_LINE) + k];

			PrintStringLine(temp);
		}
	}
}


/*******************************************************************************
 * Function Name  : PrinterHavePaper
 * Description    : Check if there is a paper in printer
 *******************************************************************************/
bool PrinterHavePaper()
{
	GPIO_SetBits(GPIOB, GPIO_Pin_5);
	delay_ms(1);
	bool temp = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_2);
	GPIO_ResetBits(GPIOB, GPIO_Pin_5);

	return temp;
}


/*******************************************************************************
 * Function Name  : PrintString
 * Description    : Delay for burn dots
 *******************************************************************************/
void TIM2_IRQHandler()
{
	if(TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
	{
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
		GPIO_SetBits(GPIOC, GPIO_Pin_14 | GPIO_Pin_15); //reset heating dots
		isPrinting = false;
	}
}


/*******************************************************************************
 * Function Name  : TIM4_IRQHandler
 * Description    : Delay for step motor
 *******************************************************************************/
void TIM4_IRQHandler()
{
	if(TIM_GetITStatus(TIM4, TIM_IT_Update) != RESET)
	{
		TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
		stepIsActive = false;
	}
}


/*******************************************************************************
 * Function Name  : PrintCode128
 * Description    : Print CODE 128
 *******************************************************************************/
void PrintCode128(uint8_t *s)
{
	PrinterResetBuffer();

	Code128Make(printBuffer, s, 12);

//	if(printDensity < 9)
//		printDensity += 1;

	GPIO_SetBits(GPIOB, GPIO_Pin_5);
	GPIO_SetBits(GPIOC, GPIO_Pin_2 | GPIO_Pin_3);

	_PrinterRotate(5 * 1, PRINTER_FORWARD); // 5 dots at top

	for(uint8_t i=0; i<80; i++)
		_PrinterPutLine(2);

	_PrinterRotate(5 * 1, PRINTER_FORWARD); // 5 dots at bottom

	GPIO_ResetBits(GPIOC, GPIO_Pin_2 | GPIO_Pin_3);
	GPIO_ResetBits(GPIOB, GPIO_Pin_5);
//
//	if(printDensity >= 1)
//		printDensity -= 1;
}


/*******************************************************************************
 * Function Name  : PrintQrCode
 * Description    : Print 2D QR Barcode (VERSION 2, LEVEL 2 -
 * 					up to 26 byte sumbols)
 *******************************************************************************/
void PrintQrCode(uint8_t *mass, uint8_t len)
{
#define scale 3

	//strcpy_((uint8_t*)strinbuf, (uint8_t*)"KASBI 03 MF");

	for(uint8_t i=0; i<len; i++)
	{
		strinbuf[2 * i + 0] = ((mass[i] / 16) > 9) ? (mass[i] / 16) + 'A' - 10 : (mass[i] / 16) + '0';
		strinbuf[2 * i + 1] = ((mass[i] % 16) > 9) ? (mass[i] % 16) + 'A' - 10 : (mass[i] % 16) + '0';
	}
	strinbuf[2 * len] = '\0';

	qrencode();
//	PrintNumWDesc("SCALE = ", scale);

	if(printDensity < 9)
		printDensity += 1;

	GPIO_SetBits(GPIOB, GPIO_Pin_5);
	GPIO_SetBits(GPIOC, GPIO_Pin_2 | GPIO_Pin_3);

	for(uint16_t i = 0; i < WDB; i++) //WDB = number of rows * 8
	{
		for(uint16_t k = 0; k < 8; k++)
		{
			PrinterResetBuffer();

			for(uint16_t j = 0, pointer = 110; j < WD; j++) // WD = number of columns
				for(uint16_t m = 0; m < scale * 2; m++, pointer++)
					BitWrite((QRBIT(j, ((i * 8) + k)) << (j % 8)), printBuffer[pointer/8], pointer%8);

			for(uint8_t i = 0; i < scale; i++)
				_PrinterPutLine(4);
		}
	}

	GPIO_ResetBits(GPIOC, GPIO_Pin_2 | GPIO_Pin_3);
	GPIO_ResetBits(GPIOB, GPIO_Pin_5);

	if(printDensity >= 1)
		printDensity -= 1;

	_PrinterRotate(2 * 1, PRINTER_FORWARD);
}












/// some tests

void PrintChristmasTree()
{
	GPIO_SetBits(GPIOB, GPIO_Pin_5);
	GPIO_SetBits(GPIOC, GPIO_Pin_2 | GPIO_Pin_3);

	for(uint8_t i = 0; i < 50; i++)
	{
		PrinterResetBuffer();
		for(uint8_t k = 0; k < i; k++)
		{
			PrinterSetBufferPixel(174 + k);
			PrinterSetBufferPixel(174 - k);
		}
		_PrinterPutLine(5);
	}

	delay_ms(200);

	for(uint8_t i = 0; i < 40; i++)
	{
		PrinterResetBuffer();
		for(uint16_t i = 174 - 30; i < 174 + 30; i++)
		{
			PrinterSetBufferPixel(i);
		}
		for(uint8_t k = 0; k < i * 3 / 2; k++)
		{
			PrinterSetBufferPixel(174 + 30 + k);
			PrinterSetBufferPixel(174 - 30 - k);
		}
		_PrinterPutLine(5);
	}

	delay_ms(200);

	for(uint8_t i = 0; i < 40; i++)
	{
		PrinterResetBuffer();
		for(uint16_t i = 174 - 60; i < 174 + 60; i++)
		{
			PrinterSetBufferPixel(i);
		}
		for(uint8_t k = 0; k < i * 2; k++)
		{
			PrinterSetBufferPixel(174 + 60 + k);
			PrinterSetBufferPixel(174 - 60 - k);
		}
		_PrinterPutLine(5);
	}

	delay_ms(200);

	for(uint8_t i = 0; i < 40; i++)
	{
		delay_ms(1);

		PrinterResetBuffer();

		for(uint16_t i = 174 - 90; i < 174 + 90; i++)
			PrinterSetBufferPixel(i);

		for(uint8_t k = 0; k < i * 5 / 2; k++)
		{
			PrinterSetBufferPixel(174 + 90 + k);
			PrinterSetBufferPixel(174 - 90 - k);
		}
		_PrinterPutLine(5);
	}
	delay_ms(200);

	for(uint8_t i = 0; i < 25; i++)
	{
		PrinterResetBuffer();

		for(uint16_t i = 174 - 40; i < 174 + 40; i++)
			PrinterSetBufferPixel(i);

		_PrinterPutLine(5);
	}

	GPIO_ResetBits(GPIOC, GPIO_Pin_2 | GPIO_Pin_3);
	GPIO_ResetBits(GPIOB, GPIO_Pin_5);
}
