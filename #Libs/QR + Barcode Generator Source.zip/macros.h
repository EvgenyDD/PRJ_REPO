/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef MACROS_H
#define MACROS_H

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
//#include "stm32f10x_adc.h"
#include "stm32f10x_gpio.h"
//#include "stm32f10x_spi.h"
//#include "stm32f10x_i2c.h"
//#include "stm32f10x_tim.h"
//#include "stm32f10x_usart.h"

#include "string.h"
#include "Common.h"
#include "menu.h"
#include "macros.h"

#include "keyboard.h"
#include "sound.h"
#include "display.h"

#include "hw_hal.h"
#include "display.h"
#include "ExtFlash.h"
#include "ExtUART.h"
#include "FP.h"
#include "printer.h"
#include "RTC.h"
#include "timework.h"
#include "UI.h"

#include "Tests.h"

#include "Kalculator.h"

#include "debug.h"

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
extern uint8_t HEADER[7][19];
extern uint8_t INDIK[24][11];
extern uint8_t printBuf[PRINTER_LINE];
extern uint8_t dispBuf[DISPLAY_WIDTH+1];
extern uint8_t DetectName[8][19];
extern MenuItem *CurrMenuItem;

extern uint8_t DashLine[];

extern uint32_t vv;
extern uint8_t vvKey[15];

/* Exported macro ------------------------------------------------------------*/
#define BitSet(p,m) ((p) |= (1<<(m)))
#define BitReset(p,m) ((p) &= ~(1<<(m)))
#define BitFlip(p,m) ((p) ^= (1<<(m)))
#define BitWrite(c,p,m) ((c) ? BitSet(p,m) : BitReset(p,m))
#define BitIsSet(reg, bit) (((reg) & (1<<(bit))) != 0)
#define BitIsReset(reg, bit) (((reg) & (1<<(bit))) == 0)

#define swap(x, y, T) do { T SWAP = x; x = y; y = SWAP; } while (0)


/* Exported define -----------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
void delay_ms(uint32_t nTime);
void delay_500us(uint32_t nTime);

void ErrorWork(uint8_t* dispData);
void EndWork();
void ErrorContrReprt();

void RecoveryFlashPassw();
void RecoveryFlashSett();
void RecoveryFlashINFO();
void RecoveryFlashRecpt();
void RecoveryFlashRoute();
void RecoveryFlashReport();

void ClearBuffer(uint8_t *, uint16_t, char);
uint8_t BufferIsNotClear(uint8_t *s, uint16_t len);

void WriteTimeDateBuf(uint8_t *mass, RTC_TimeDateTypeDef X);
void WriteBuf32MSB(uint8_t *mass, uint32_t value);
void WriteBuf16MSB(uint8_t *mass, uint16_t value);

void WriteFracBuf(uint8_t *mass, int32_t number);

#endif //MACROS_H
