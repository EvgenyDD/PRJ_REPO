/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _QRENCODE_H
#define _QRENCODE_H

/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported variables --------------------------------------------------------*/
extern unsigned char strinbuf[];
extern unsigned char qrframe[];

extern unsigned char  WD, WDB;

/* Exported macro ------------------------------------------------------------*/
#define QRBIT(x,y) 		( ( qrframe[((x)>>3)/* *8 */ + (y) * WDB] >> (7-((x) & 7 ))) & 1 )
#define SETQRBIT(x,y) 		qrframe[((x)>>3) + (y) * WDB] |= 0x80 >> ((x) & 7)
#define TOGQRBIT(x,y) 		qrframe[((x)>>3) + (y) * WDB] ^= 0x80 >> ((x) & 7)

/* Exported define -----------------------------------------------------------*/
#define memcpy_P memcpy
#define __LPM(x) *x
#define pgm_read_word(x) *x

/* Exported functions ------------------------------------------------------- */
void qrencode(void);
void PrintQrCode(uint8_t *mass, uint8_t len);

#endif //_QRENCODE_H




