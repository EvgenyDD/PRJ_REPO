/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _CODE128_H
#define _CODE128_H

/* Includes ------------------------------------------------------------------*/
#include "stm32F10x.h"

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported define -----------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
void PrintCode128(uint8_t *);
void Code128Make(uint8_t *dest, uint8_t *source, uint8_t len);

#endif //_CODE128_H
