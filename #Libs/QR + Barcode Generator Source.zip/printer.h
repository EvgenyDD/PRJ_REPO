/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef PRINTER_H
#define PRINTER_H

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
#include <stdbool.h>


/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
#define PrinterSetBufferPixel(pixel) BitSet(printBuffer[(pixel)/8], (pixel)%8)
#define PrinterResetBuffer() {for(uint8_t i = 0; i < 48; i++) printBuffer[i] = 0x00;}


/* Exported define -----------------------------------------------------------*/
#define PRINTER_DOC_END 14 //14mm to metal "knife"
#define PRINTER_LINE 27
enum{PRINTER_REVERSE=0, PRINTER_FORWARD=1};


/* Exported functions ------------------------------------------------------- */
void PrinterInit();

void PrinterStep(uint32_t num);
void PrinterStepInverse(uint32_t num);
//void _PrinterRotate(uint32_t steps);

bool PrinterHavePaper();

void PrintCode128(uint8_t *s);

void PrintStringLine(uint8_t * string);
void PrintStringCentered(uint8_t* string);
void PrintString(uint8_t* string);



void PrintChristmasTree();


#endif //PRINTER_H
