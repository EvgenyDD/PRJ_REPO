/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "Common.h"
#include "ExtFlash.h"
#include "macros.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Extern variables ----------------------------------------------------------*/
extern uint8_t vvKey[15];

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*******************************************************************************
 * Function Name  : ClearBuffer
 * Description    : Clear buffer with value
 *******************************************************************************/
void ClearBuffer(uint8_t *s, uint16_t len, char value)
{
	for(uint8_t i = 0; i < len; i++)
		s[i] = value;
}

/*******************************************************************************
 * Function Name  : BufferIsNotClear
 * Description    : Check if there is no Spaces in string with specified length
 *******************************************************************************/
uint8_t BufferIsNotClear(uint8_t *s, uint16_t len)
{
	uint8_t flag = 0;
	for(uint8_t i = 0; i < len; i++)
		if(s[i] != ' ' && s[i] != 255  && s[i] != 0)
			flag = 1;

	return flag;
}


/*******************************************************************************
 * Function Name  : WriteBuf32MSB
 * Description    : Write uint32_t to buffer
 *******************************************************************************/
void WriteBuf16MSB(uint8_t *mass, uint16_t value)
{
	mass[0] = (value >> 8) & 0xFF;
	mass[1] = (value) & 0xFF;
}

/*******************************************************************************
 * Function Name  : WriteBuf32MSB
 * Description    : Write uint32_t to buffer
 *******************************************************************************/
void WriteBuf32MSB(uint8_t *mass, uint32_t value)
{
	mass[0] = (value >> 24) & 0xFF;
	mass[1] = (value >> 16) & 0xFF;
	mass[2] = (value >> 8) & 0xFF;
	mass[3] = (value) & 0xFF;
}

/*******************************************************************************
 * Function Name  : WriteTimeDateBuf
 * Description    : Write TimeDate to buffer
 *******************************************************************************/
void WriteTimeDateBuf(uint8_t *mass, RTC_TimeDateTypeDef X)
{
	mass[0] = X.year;
	mass[1] = X.month;
	mass[2] = X.date;
	mass[3] = X.hour;
	mass[4] = X.minute;
	mass[5] = X.second;
}

/*******************************************************************************
 * Function Name  : WriteFracBuf
 * Description    : Write fraction number to buffer
 *******************************************************************************/
void WriteFracBuf(uint8_t *mass, int32_t number)
{
	uint8_t negative = number >= 0 ? 0 : 1;

	if(number < 0)
		number *= -1;

	mass[0] = number % 100;
	number /= 100;
	mass[1] = number % 100;
	number /= 100;
	mass[2] = number % 100;
	number /= 100;
	mass[3] = number % 100;
	number /= 100;
	mass[4] = number % 100;
	number /= 100;
	mass[5] = number % 100;

	BitWrite(negative, mass[5], 7);
}
