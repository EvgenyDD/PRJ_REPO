/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _SKNO_H
#define _SKNO_H

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_usart.h"
#include "misc.h"

#include "timework.h"

/* Exported types ------------------------------------------------------------*/
typedef struct{
	uint8_t busy				:1;
	uint8_t cryptActive			:1;
	uint8_t connection			:1;
	uint8_t blockedByEndCert	:1;
	uint8_t blockedByZReports	:1;
	uint8_t blockedByMemory		:1;
	uint8_t IDSuccessfull		:1;
	uint8_t ShiftOpened			:1;

	uint8_t TransferActive		:1;
	uint8_t UnsendedDocs		:1;
	uint8_t DocOverflow			:1;
	uint8_t SKNOAlive			:1;
}SKNOStatusTypeDef;

/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define _SKNO_START				0x17

#define _SKNO_SOH				0x02 //status header
#define _SKNO_EOT				0x04 //error/busy

#define _SKNO_STX				0x13 //packet start
#define _SKNO_ETX				0x05 //packet end

#define _SKNO_ACK				0xAA //packet received successfully
#define _SKNO_NACK				0x07 //request for re-send of the packet

#define _SKNO_REQ				0x33 //request

#define _SKNO_DUMMY				0x12 //byte-insertion

#define _SKNO_COM_ID			0xAA //identification request
#define _SKNO_COM_TIME_DATE		0x55 //read current time & date
#define _SKNO_COM_OPEN_SHIFT	0x40
#define _SKNO_COM_SEND_DOC		0x10
#define _SKNO_COM_CLOSE_SHIFT	0x41
#define _SKNO_COM_GET_UNID		0x11 //second request for unique ID number

#define _SKNO_PACK_DATA_OFFSET	17
#define _SKNO_RXPKT_DATA_OFFSET	((_SKNO_PACK_DATA_OFFSET)-2)

enum{SKNO_NULL=0, SKNO_ERROR=1,
	SKNO_PKT_RECEIVING=2, SKNO_PKT_RECEIVED=4, SKNO_PKT_ACKED=6, SKNO_PKT_NACKED=8,
	SKNO_REQ_RECEIVING=16, SKNO_REQ_RECEIVED=32,
	};


/* Exported define -----------------------------------------------------------*/
#define STATUS_INTERRUPTED		-5
#define STATUS_ERROR			-4
#define STATUS_BUSY				-3
#define STATUS_FAIL_COM			-2
#define STATUS_NO_ANSWER		-1
#define STATUS_SUCCESSFULL		0

#define SKNO_DOC_CHECK			0
#define SKNO_DOC_DEPOSIT		1
#define SKNO_DOC_WITHDRAWAL		2
#define SKNO_DOC_REFUND			3
#define SKNO_DOC_ANNUL			4


/* Exported functions ------------------------------------------------------- */
void SKNOInit();

int8_t SKNOWaitReadyState();
int8_t SKNOReadStatus(uint8_t debugOutEn);

int8_t SKNOSendID();
int8_t SKNOReadDateTime();
int8_t SKNOWaitReadyState();
int8_t SKNOOpenShift();
int8_t SKNOSendDoc(uint8_t command);
int8_t SKNOGetUID();
int8_t SKNOCloseShift();

uint16_t CRC16_CCITT_CalcMass(uint8_t *data, uint16_t size);


#endif //_SKNO_H
