#pragma once

void init_serial();
unsigned char serial_getchar();
