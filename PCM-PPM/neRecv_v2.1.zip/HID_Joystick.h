#pragma once

// runs neRecv in HID joystick mode
void HID_Joystick();