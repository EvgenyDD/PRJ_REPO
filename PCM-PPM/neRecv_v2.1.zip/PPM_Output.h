#pragma once

// we want negative ppm
// comment this out to get positive PPM
#define NEGATIVE_PPM

// runs neRecv in PPM mode
void PPM_Output();
